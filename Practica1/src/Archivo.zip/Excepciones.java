package Practica1;

public class Excepciones extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8494776413748484477L;

	public Excepciones(String s) {
		super(s);
	}
}
