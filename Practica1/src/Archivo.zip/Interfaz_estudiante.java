package Practica1;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import javax.swing.JButton;

public class Interfaz_estudiante extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5911693782544364189L;
	private JFrame frame_interfaz_estudiante;
	
	

	public JFrame getFrame_Aula() {
		return frame_interfaz_estudiante;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interfaz_estudiante window = new Interfaz_estudiante();
					window.frame_interfaz_estudiante.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Interfaz_estudiante() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame_interfaz_estudiante = new JFrame();
		frame_interfaz_estudiante.setResizable(false);
		frame_interfaz_estudiante.setBounds(100, 100, 380, 446); //-, - , ancho, alto
		frame_interfaz_estudiante.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_interfaz_estudiante.getContentPane().setLayout(null);
		
		JButton btnLogin_ingresar = new JButton("Estudiante");
		btnLogin_ingresar.setBounds(132, 309, 117, 29);
		frame_interfaz_estudiante.getContentPane().add(btnLogin_ingresar);
		btnLogin_ingresar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Interfaz_Login AtrasLogin= new Interfaz_Login();
				AtrasLogin.getFrame_Login().setVisible(true);
				Interfaz_estudiante.this.frame_interfaz_estudiante.dispose();
				
			}
		});
	}
}
